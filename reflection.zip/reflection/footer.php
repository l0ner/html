  </div>

<div id="footer">
Powered by <a href="http://wordpress.org/">WordPress <?php bloginfo('version');?></a>, <a href="http://photoblog.xyloid.org/reflection/">Reflection</a> 
and <a href="http://johannes.jarolim.com/yapb/">YAPB</a>: <a href="#">Entries (RSS)</a> and <a href="#">Comments (RSS)</a>.<br />

All images and content are copyright &copy; Your Name 2008.
</div>

</body>

</html>
